export default {
  courses: [],
  authors: [],
  ajaxCallsInProgress: 0
};
