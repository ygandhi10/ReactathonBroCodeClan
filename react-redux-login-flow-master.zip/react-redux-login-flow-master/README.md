# React Redux Login Flow
A simple application to demonstrate a login flow with React & Redux.
Read full tutorial at here: [A simple login flow with React and Redux](http://jslancer.com/2017/04/27/a-simple-login-flow-with-react-and-redux)

![ezgif com-video-to-gif](https://cloud.githubusercontent.com/assets/1154740/25493010/fed3b2cc-2b9e-11e7-8736-9250549128ec.gif)


# Usage
```
git clone https://github.com/davidtran/react-redux-login-flow
npm intall
npm start
```

